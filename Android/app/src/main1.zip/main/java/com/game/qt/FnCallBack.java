package com.game.qt;


/**
 * Created by Jeffery on 2017/12/19.
 */

public interface FnCallBack {
    void responseCallback(String datas);
}
