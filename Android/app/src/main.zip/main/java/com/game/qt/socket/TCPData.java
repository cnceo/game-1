package com.game.qt.socket;

/**
 * Created by Administrator on 2017/1/4.
 */

public class TCPData {

    private String content;

    public TCPData() {
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
