package com.game.qt.jsbridge;

/**
 * Created by Administrator on 2018/1/17.
 */

public interface BridgeHandler {

    void handler(String data, CallBackFunction function);

}
