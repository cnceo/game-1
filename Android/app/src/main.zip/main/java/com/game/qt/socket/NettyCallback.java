package com.game.qt.socket;

/**
 * Created by xf on 14/12/2017.
 */

public interface NettyCallback {
    void responseCallback(ResponseMessage responseMessage);
}
