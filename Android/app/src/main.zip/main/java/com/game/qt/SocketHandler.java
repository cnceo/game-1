package com.game.qt;

import android.content.Context;
import android.os.Looper;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.game.qt.socket.CallBackSingleton;
import com.game.qt.socket.ChannelManager;
import com.game.qt.socket.JsonUtil;
import com.game.qt.socket.NettyCallback;
import com.game.qt.socket.NettyClient;
import com.game.qt.socket.RequestMessage;
import com.game.qt.socket.ResponseMessage;
import com.github.lzyzsd.jsbridge.BridgeWebView;
import com.github.lzyzsd.jsbridge.CallBackFunction;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;

/**
 * Created by Jeffery on 2017/12/23.
 */

public class SocketHandler {
    public static CallBackFunction callBack1;
    public static BridgeWebView bridgeView1;
    public static CallBackFunction callBack2;
    public static BridgeWebView bridgeView2;
    public static CallBackFunction callBack3;
    public static BridgeWebView bridgeView3;
    public static CallBackFunction callBack4;
    public static BridgeWebView bridgeView4;
    public static CallBackFunction callBack5;
    public static BridgeWebView bridgeView5;
    public static ChannelManager channelManager;
    public static void initSocketConnect (Map map, int command) {
        channelManager = ChannelManager.getInstance();

        RequestMessage requestMessage = new RequestMessage();
        requestMessage.setCommand(command);
        requestMessage.setData(JsonUtil.toJson(map));
        channelManager.getChannel("888888").writeAndFlush(requestMessage).addListener(new ChannelFutureListener() {
            @Override
            public void operationComplete(ChannelFuture channelFuture) throws Exception {
                if (channelFuture.channel().isOpen() && !channelFuture.isSuccess()) {
                    Log.d("SuccessSend","数据发送成功");
                }
            }
        });
    }
    public static void connectUserSocket (Map map, int command, CallBackFunction function, BridgeWebView bridgeWebView) {
        callBack1 = function;
        bridgeView1 = bridgeWebView;
        initSocketConnect(map, command);
        channelManager.setCallback(new NettyCallback() {
            @Override
            public void responseCallback(ResponseMessage responseMessage) {
                if (Thread.currentThread() == Looper.getMainLooper().getThread()) {
                    Log.d("SuccessSend","主线程");
                } else {
                    Log.d("SuccessSend","子线程");
                }
                if (responseMessage.getData() == null) {
                    Log.e("数据为空", "null");
                } else {
                    Log.i("返回的用户列表为", responseMessage.getData().toString());
//                    ObjectMapper mapper = new ObjectMapper();
//                    String json = "";
//                    json = mapper.writeValueAsString(responseMessage.getData().toString());
//                    Gson gson = new Gson();
//                    String json = gson.toJson(responseMessage.getData());
//                    String str= JSON.toJSON(responseMessage.getData()).toString();
                    String json = JSON.toJSONString(responseMessage.getData());
                    callBack1.onCallBack(json);
//                CallBackFunction callBackFunction = (CallBackFunction) CallBackSingleton.getObject(key);
//                callBackFunction.onCallBack(responseMessage.getData().toString());
                    bridgeView1.callHandler("updateUsers", json, new CallBackFunction() {

                        @Override
                        public void onCallBack(String data) {
                            //    Toast.makeText(getApplicationContext(), data, Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }
        });
    }
    public static String parseListForMapsToJsonArrayStr(List<Map<String, Object>> list) {
        String jsonArrayStr = null;
        if(list != null && list.size() != 0) {
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObject = null;
            Object value = null;
            for(Map<String, Object> map : list) {
                jsonObject = new JSONObject();
                Set<String> set;
                set = map.keySet();
                for(String key : set) {
                    value = map.get(key);
                    if(value != null) {
                        try {
                            jsonObject.put(key, value.toString());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if(jsonObject.length() != 0) {
                    jsonArray.put(jsonObject);
                }
            }
            jsonArrayStr = jsonArray.toString();
        }

        return jsonArrayStr;
    }
    public static void connectCardSocket (Map map, int command, CallBackFunction function, BridgeWebView bridgeWebView) {
        callBack2 = function;
        bridgeView2 = bridgeWebView;
        initSocketConnect(map, command);
        channelManager.setCallback(new NettyCallback() {
            @Override
            public void responseCallback(ResponseMessage responseMessage) {
                if (Thread.currentThread() == Looper.getMainLooper().getThread()) {
                    Log.d("SuccessSend","主线程");
                } else {
                    Log.d("SuccessSend","子线程");
                }
                String json = JSON.toJSONString(responseMessage.getData());
                callBack2.onCallBack(json);
//                CallBackFunction callBackFunction = (CallBackFunction) CallBackSingleton.getObject(key);
//                callBackFunction.onCallBack(responseMessage.getData().toString());
                bridgeView2.callHandler("updateCards", json, new CallBackFunction() {

                    @Override
                    public void onCallBack(String data) {
                        //    Toast.makeText(getApplicationContext(), data, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
    public static void connectReleaseWaitSocket (Map map, int command, CallBackFunction function, BridgeWebView bridgeWebView) {
        callBack3 = function;
        bridgeView3 = bridgeWebView;

        initSocketConnect(map, command);
        channelManager.setCallback(new NettyCallback() {
            @Override
            public void responseCallback(ResponseMessage responseMessage) {
                if (Thread.currentThread() == Looper.getMainLooper().getThread()) {
                    Log.d("SuccessSend","主线程");
                } else {
                    Log.d("SuccessSend","子线程");
                }
                String json = JSON.toJSONString(responseMessage.getData());
                callBack3.onCallBack(json);
//                CallBackFunction callBackFunction = (CallBackFunction) CallBackSingleton.getObject(key);
//                callBackFunction.onCallBack(responseMessage.getData().toString());
                bridgeView3.callHandler("releaseWait", json, new CallBackFunction() {

                    @Override
                    public void onCallBack(String data) {
                        //    Toast.makeText(getApplicationContext(), data, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
    public static void connectReleaseReadySocket (Map map, int command, CallBackFunction function, BridgeWebView bridgeWebView) {
        callBack4 = function;
        bridgeView4 = bridgeWebView;
        initSocketConnect(map, command);
        channelManager.setCallback(new NettyCallback() {
            @Override
            public void responseCallback(ResponseMessage responseMessage) {
                if (Thread.currentThread() == Looper.getMainLooper().getThread()) {
                    Log.d("SuccessSend","主线程");
                } else {
                    Log.d("SuccessSend","子线程");
                }
                String json = JSON.toJSONString(responseMessage.getData());
                callBack4.onCallBack(json);
//                CallBackFunction callBackFunction = (CallBackFunction) CallBackSingleton.getObject(key);
//                callBackFunction.onCallBack(responseMessage.getData().toString());
                bridgeView4.callHandler("releaseReady", json, new CallBackFunction() {

                    @Override
                    public void onCallBack(String data) {
                        //    Toast.makeText(getApplicationContext(), data, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    public static void updateResult (Map map, int command, CallBackFunction function, BridgeWebView bridgeWebView) {
        callBack5 = function;
        bridgeView5 = bridgeWebView;
        initSocketConnect(map, command);
        channelManager.setCallback(new NettyCallback() {
            @Override
            public void responseCallback(ResponseMessage responseMessage) {
                if (Thread.currentThread() == Looper.getMainLooper().getThread()) {
                    Log.d("SuccessSend","主线程");
                } else {
                    Log.d("SuccessSend","子线程");
                }
                Log.e("SuccessSend",responseMessage.getData().toString());
                String json = JSON.toJSONString(responseMessage.getData());
                callBack5.onCallBack(json);
//                CallBackFunction callBackFunction = (CallBackFunction) CallBackSingleton.getObject(key);
//                callBackFunction.onCallBack(responseMessage.getData().toString());
                bridgeView5.callHandler("updateResult", json, new CallBackFunction() {

                    @Override
                    public void onCallBack(String data) {
                        //    Toast.makeText(getApplicationContext(), data, Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}
