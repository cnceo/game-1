package com.game.qt;

import com.tencent.mm.opensdk.openapi.IWXAPI;

public class Constants {
    public static final String APP_SECRET = "d676980394fa3b9c1591fe8b87c461e5";
    public static final String APP_ID = "wx54bbd36a546bdf23";
    public static final int INVATE = 0;
    public static final int SHARE = 1;
    public static IWXAPI wx_api ;
    public static final String URL = "http://www.syhpgkj.com:8080";
    public static boolean flag = false;
}