package com.game.qt.jsbridge;

public interface CallBackFunction {

    public void onCallBack(String data);

}
