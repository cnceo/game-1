package com.game.qt.socket;

/**
 * Created by Administrator on 2018/1/20 0020.
 */

public interface NettyReconnectCallback {
    void reconnectCallback();
}
